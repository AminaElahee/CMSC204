//This class inherits from Exception.When initialized with a message, it calls the parent class with the message.
public class NoSpecialCharacterException extends Exception {
	

	public NoSpecialCharacterException(String message)
	{
		super(message);
	}

}
