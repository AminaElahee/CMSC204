/*
 * Class: CMSC204
 * Instructor: Khandan Monshi   
 * Description: Checking for a valid password
 * Due: 02/11/2025
 * Platform/compiler:
 * I pledge that I have completed the programming 
assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any student.
 * Print your Name here: _Amina Elahee_
*/



import java.util.ArrayList;

public class PasswordCheckerUtility {

	 // private static final int MIN_LENGTH = 6;
	 
	  
	  
	public PasswordCheckerUtility()
	{
		
	}
	
	
	public static void comparePasswords​(String password, String passwordConfirm) throws UnmatchedException
	{
		if (!(password.equals(passwordConfirm)))
		{
			throw new UnmatchedException("Passwords do not match");
			
			
		}
	}
	
	public static boolean comparePasswordsWithReturn​(String password, String passwordConfirm)
	{
//		if (!(password.equals(passwordConfirm)))
//		{
//			return false;
//		}
//		
//		return true;
		
		return password.equals(passwordConfirm);
		
	}
	
	public static boolean isValidLength​(String password) throws LengthException
	{
		if(password.length()<6)
		{
			throw new LengthException("The password must be at least 6 characters long");
		}
		
		return true;
		
	}
	
	public static boolean hasUpperAlpha​(String password) throws NoUpperAlphaException
	{
		for(int i=0;i<password.length();i++)
		{
			if(Character.isUpperCase(password.charAt(i)))
			{
				return true;
			}
					
		}
		
		throw new NoUpperAlphaException("No uppercase in the password");
	}
	
	
	public static boolean hasLowerAlpha​(String password) throws NoLowerAlphaException
	{
		for(int i=0;i<password.length();i++)
		{
			if(Character.isLowerCase(password.charAt(i)))
			{
				return true;

			}
					
		}
		
		throw new NoLowerAlphaException("The password must contain at least one lowercase alphabetic character");
	}
	
	
	public static boolean hasDigit​(String password) throws NoDigitException 
	{
		
		for(int i=0;i<password.length();i++)
		{
			if(Character.isDigit(password.charAt(i)))
			{
				return true;
			}
					
		}
		
		
		throw new NoDigitException("No digit in the password");
	}
	
	public static boolean hasSpecialChar​(String password) throws NoSpecialCharacterException
	{	
		
		
		for(int i=0;i<password.length();i++)
		{
			char c = password.charAt(i);

	       
	        if (((c >= 33 && c <= 47)|| (c >= 58 && c <= 64) || (c >= 91 && c <= 96) || (c >= 123 && c <= 126)))
	        { 
	          return true;
	        }
					
		}
		
		
		throw new NoSpecialCharacterException("The password must contain at least one special character");

		
	}
	
	public static boolean NoSameCharInSequence​(String password) throws InvalidSequenceException
	{
		
		for(int i=0;i<password.length()-2;i++)
		{
			
			
				if(password.charAt(i)==password.charAt(i+1)&& password.charAt(i+1)==password.charAt(i+2))
				{
					throw new InvalidSequenceException("The password cannot contail more than two of the same character in sequence");
				}
				
				
			
			
		}
		
		return true;
		
	}
	
	public static boolean isValidPassword​(String password) throws LengthException, 
	NoUpperAlphaException, NoLowerAlphaException,NoDigitException, NoSpecialCharacterException, InvalidSequenceException
	{
		
		return isValidLength​(password) && hasUpperAlpha​(password) && hasLowerAlpha​(password) && hasDigit​(password) &&hasSpecialChar​(password) && NoSameCharInSequence​(password);
		
		
	}
	
	public static boolean hasBetweenSixAndNineChars​(String password)
	{
	
		return password.length() >= 6 && password.length() <= 9;
		
	}
	
	public static boolean isWeakPassword​(String password) throws WeakPasswordException
	{
		if (hasBetweenSixAndNineChars​(password)) 
		{
            throw new WeakPasswordException("Password is weak. Consider using 10 or more characters.");
        }
		
        return false;
	}
	
	public static ArrayList<String> getInvalidPasswords​(ArrayList<String> passwords)
	{
		 ArrayList<String> invalidPasswords = new ArrayList<>();
	        
	        for (String password : passwords) {
	            try {
	                isValidPassword​(password);
	            } catch (Exception e) {
	                invalidPasswords.add(password +" "+ e.getMessage());
	            }
	        }
	        return invalidPasswords;
	        
	       
	    
	}
	
}
