//This class inherits from Exception.When initialized with a message, it calls the parent class with the message.
public class UnmatchedException extends Exception {
	
	
	public UnmatchedException(String message)
	{
		super(message);
	}

}
