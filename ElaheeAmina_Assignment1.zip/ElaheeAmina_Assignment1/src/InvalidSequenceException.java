//This class inherits from Exception.When initialized with a message, it calls the parent class with the message.

public class InvalidSequenceException extends Exception {
	public InvalidSequenceException(String message)
	{
		super(message);
	}

}
