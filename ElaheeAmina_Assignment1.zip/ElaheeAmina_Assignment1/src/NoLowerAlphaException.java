//This class inherits from Exception.When initialized with a message, it calls the parent class with the message.
public class NoLowerAlphaException extends Exception {
	
	
	public NoLowerAlphaException(String message)
	{
		super(message);
	}

}
